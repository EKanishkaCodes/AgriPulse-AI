import base64
from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
load_dotenv()
import vision_pathology as vp, vernacular_tts as tts
from phone import router as phone_router

app = FastAPI(title="AgriPulse AI")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.include_router(phone_router)

LANGS = {  # UI code -> (name for the LLM, Seamless code)
    "ta": ("Tamil", "tam"), "en": ("English", "eng"),
}

@app.get("/health")
def health(): return {"ok": True}

@app.post("/diagnose")
async def diagnose(image: UploadFile = File(...), lang: str = Form("en"),
                   query: str = Form(""), edge_hint: str = Form("")):
    if lang not in LANGS: raise HTTPException(400, "Unsupported language")
    data = await image.read()
    if len(data) > 8_000_000: raise HTTPException(413, "Image too large")
    try:
        result = vp.diagnose(data, image.content_type or "image/jpeg", LANGS[lang][0], query, edge_hint)
    except Exception as e:
        raise HTTPException(502, f"Diagnosis failed: {e}")
    wav = tts.synthesize(result.get("treatment_plan_vernacular", ""), LANGS[lang][1])
    result["audio_b64"] = base64.b64encode(wav).decode() if wav else None
    return result

@app.post("/transcribe")
async def transcribe(audio: UploadFile = File(...), lang: str = Form("en")):
    return {"text": tts.transcribe(await audio.read(), lang)}
