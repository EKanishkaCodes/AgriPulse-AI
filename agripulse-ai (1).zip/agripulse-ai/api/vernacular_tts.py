"""Optional server-side speech. Returns None so the client falls back to the
browser's built-in speechSynthesis / SpeechRecognition."""
import io, os

_seamless = None

def synthesize(text: str, lang_code: str):
    """WAV bytes via Meta SeamlessM4T (3-letter codes: hin, swh, spa, arb), or None."""
    global _seamless
    if os.getenv("ENABLE_SEAMLESS") != "1" or not text:
        return None
    try:
        import scipy.io.wavfile as wav
        from transformers import AutoProcessor, SeamlessM4Tv2Model
        if _seamless is None:
            name = "facebook/seamless-m4t-v2-large"
            _seamless = (AutoProcessor.from_pretrained(name), SeamlessM4Tv2Model.from_pretrained(name))
        proc, model = _seamless
        inputs = proc(text=text, src_lang=lang_code, return_tensors="pt")
        audio = model.generate(**inputs, tgt_lang=lang_code, generate_speech=True)[0].cpu().numpy().squeeze()
        buf = io.BytesIO(); wav.write(buf, 16000, audio); return buf.getvalue()
    except Exception:
        return None

def transcribe(audio_bytes: bytes, language: str | None = None) -> str:
    """Whisper API speech-to-text. Returns '' if not configured."""
    if not os.getenv("OPENAI_API_KEY"):
        return ""
    from openai import OpenAI
    f = io.BytesIO(audio_bytes); f.name = "audio.webm"
    return OpenAI().audio.transcriptions.create(model="whisper-1", file=f, language=language).text
