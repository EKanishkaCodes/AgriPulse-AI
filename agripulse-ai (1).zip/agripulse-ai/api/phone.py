"""Keypad-phone access via Twilio webhooks. Each disease has a number (see diseases.py).
Voice: POST /phone/voice  ·  SMS: POST /phone/sms (text the disease number, or describe the problem)."""
from fastapi import APIRouter, Form, Response
from xml.sax.saxutils import escape
import vision_pathology as vp
from diseases import DISEASES, TAIL

router = APIRouter(prefix="/phone")
LANG = {"1": ("en-IN", "en"), "2": ("ta-IN", "ta")}
INTRO = {"en": "Press the disease number, then press hash. ", "ta": "நோய் எண்ணை அழுத்தி, பிறகு # அழுத்தவும். "}
UNSURE = {"en": "Not sure. Ask your local extension worker, or send a leaf photo.",
          "ta": "உறுதியாகத் தெரியவில்லை. உள்ளூர் வேளாண் அலுவலரிடம் கேளுங்கள், அல்லது இலையின் புகைப்படம் அனுப்புங்கள்."}
BAD = {"en": "That number is not on the list. Try again. ", "ta": "அந்த எண் பட்டியலில் இல்லை. மீண்டும் முயற்சிக்கவும். "}

def twiml(body: str) -> Response:
    return Response(f'<?xml version="1.0" encoding="UTF-8"?><Response>{body}</Response>', media_type="application/xml")

def name(z, k): return z["n"] if k == "en" else z["t"]
def advice(z, k): return (z["e"] if k == "en" else z["a"]) + " " + TAIL[k][z["u"]]
def listing(k): return " ".join(f"{i}, {name(z, k)}." for i, z in enumerate(DISEASES, 1))

@router.post("/voice")
def voice():
    return twiml('<Gather numDigits="1" action="/phone/lang" timeout="8">'
                 '<Say language="en-IN">Welcome to AgriPulse. For English press 1.</Say>'
                 '<Say language="ta-IN">தமிழுக்கு 2 ஐ அழுத்தவும்.</Say></Gather><Redirect>/phone/voice</Redirect>')

@router.post("/lang")
def lang(Digits: str = Form(""), prefix: str = ""):
    if Digits not in LANG: return twiml("<Redirect>/phone/voice</Redirect>")
    code, k = LANG[Digits]
    return twiml(f'<Gather finishOnKey="#" timeout="10" action="/phone/advice?l={Digits}">'
                 f'<Say language="{code}">{escape(prefix + INTRO[k] + listing(k))}</Say></Gather>'
                 f'<Redirect method="POST">/phone/voice</Redirect>')

@router.post("/advice")
def pick(l: str = "1", Digits: str = Form("")):
    code, k = LANG.get(l, LANG["1"])
    if not Digits.isdigit(): return twiml(f'<Redirect method="POST">/phone/lang?Digits={l}</Redirect>')
    n = int(Digits)
    if n == 0: return twiml(f'<Say language="{code}">{escape(UNSURE[k])}</Say><Hangup/>')
    if not 1 <= n <= len(DISEASES):
        return twiml(f'<Gather finishOnKey="#" timeout="10" action="/phone/advice?l={l}"><Say language="{code}">'
                     f'{escape(BAD[k] + listing(k))}</Say></Gather>')
    z = DISEASES[n - 1]
    return twiml(f'<Say language="{code}">{escape(name(z, k) + ". " + advice(z, k))}</Say><Hangup/>')

@router.post("/sms")
def sms(Body: str = Form("")):
    t = Body.strip()
    if t.isdigit() and 1 <= int(t) <= len(DISEASES):          # farmer texted a disease number
        z = DISEASES[int(t) - 1]
        return twiml(f"<Message>{escape(z['n'] + ': ' + advice(z, 'en') + chr(10) + z['t'] + ': ' + advice(z, 'ta'))}</Message>")
    try: text = vp.advise_text(f"Farmer's text message: {t}", "the same language as the message")
    except Exception: text = "Sorry, please try again later or ask your local extension worker."
    return twiml(f"<Message>{escape(text)}</Message>")
