"""Gemini vision executor – returns the structured JSON defined in the system prompt."""
import json, os, re
import google.generativeai as genai

AGRI_SYSTEM_PROMPT = """
You are AgriPulse AI, an expert agricultural pathologist advising smallholder farmers.
Analyze the plant image and farmer's spoken query to provide immediate, actionable diagnostic advice.

RULES:
1. IDENTIFY PATHOGEN: Name the plant disease or pest accurately (e.g., Tomato Early Blight).
2. LOCAL & AFFORDABLE REMEDIES: Prioritize low-cost, organic, or easily accessible treatments.
3. CLEAR DOSAGE INSTRUCTIONS: Provide simple step-by-step application instructions (e.g., 'Mix 2 tablespoons of baking soda in 1 bucket of water').
4. PREVENTATIVE CARE: Include 1-2 practical tips to prevent spread to neighboring crops.
5. If the image is unclear or not a plant, say so and set confidence_score below 0.3.
6. Write treatment_plan_vernacular in the requested language, in short spoken sentences, no markdown.

OUTPUT FORMAT (JSON ONLY):
{
  "crop_identified": "string",
  "health_status": "Healthy / Diseased / Pest Infestation",
  "diagnosis_name": "string",
  "confidence_score": number between 0 and 1,
  "severity_level": "Low / Moderate / High",
  "treatment_plan_vernacular": "Clear, simple explanation meant for text-to-speech conversion",
  "preventative_measures": ["string"]
}
"""

_model = None

def _get_model():
    global _model
    if _model is None:
        genai.configure(api_key=os.environ["GEMINI_API_KEY"])
        _model = genai.GenerativeModel(
            os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
            system_instruction=AGRI_SYSTEM_PROMPT,
            generation_config={"response_mime_type": "application/json", "temperature": 0.2},
        )
    return _model

def diagnose(image_bytes: bytes, mime: str, language: str, query: str = "", edge_hint: str = "") -> dict:
    parts = [
        {"mime_type": mime, "data": image_bytes},
        f"Respond in: {language}\nFarmer's question: {query or '(none)'}\n"
        f"On-device model guess (may be wrong): {edge_hint or 'n/a'}",
    ]
    text = _get_model().generate_content(parts).text
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    return json.loads(text)


def advise_text(problem: str, language: str) -> str:
    """Text-only advice for phone calls and SMS (no photo)."""
    m = genai.GenerativeModel(
        os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
        system_instruction=(
            f"You advise smallholder farmers over the phone. Reply in {language}, at most 3 short spoken "
            "sentences, cheapest organic fix first, simple measures (buckets, spoonfuls). No markdown. "
            "If unsure, say a local extension worker should check the plant."),
    )
    genai.configure(api_key=os.environ["GEMINI_API_KEY"])
    return m.generate_content(problem).text.strip()
