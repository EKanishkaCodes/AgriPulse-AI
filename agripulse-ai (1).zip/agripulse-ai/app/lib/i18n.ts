export const LANGS = [
  { code: "ta", label: "தமிழ்", speech: "ta-IN" },
  { code: "en", label: "English", speech: "en-IN" },
];
export const speechCode = (c: string) => LANGS.find(l => l.code === c)?.speech ?? "en-US";
