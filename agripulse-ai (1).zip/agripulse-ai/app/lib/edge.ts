// On-device classifier (TFLite via tfjs-tflite). Returns null if the model file isn't installed.
let model: any = null, tfmod: any = null, labels: string[] = [];

export async function edgeClassify(img: HTMLCanvasElement) {
  try {
    if (!model) {
      tfmod = await import("@tensorflow/tfjs");
      const tflite = await import("@tensorflow/tfjs-tflite");
      model = await tflite.loadTFLiteModel("/models/plant_disease.tflite");
      labels = await (await fetch("/models/labels.json")).json();
    }
    const input = tfmod.tidy(() => tfmod.image.resizeBilinear(tfmod.browser.fromPixels(img), [224, 224]).expandDims(0).toFloat().div(255));
    const out = model.predict(input) as any;
    const p: number[] = Array.from(await out.data());
    input.dispose(); out.dispose();
    const i = p.indexOf(Math.max(...p));
    return { label: labels[i], confidence: p[i] };
  } catch { return null; }
}
