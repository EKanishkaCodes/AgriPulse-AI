import { get, set } from "idb-keyval";
const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";
export type Diagnosis = {
  crop_identified: string; health_status: string; diagnosis_name: string; confidence_score: number;
  severity_level: string; treatment_plan_vernacular: string; preventative_measures: string[]; audio_b64?: string | null;
};
export type Job = { id: string; image: Blob; lang: string; query: string; edgeHint: string; result?: Diagnosis };

export async function cloudDiagnose(j: Job): Promise<Diagnosis> {
  const f = new FormData();
  f.append("image", j.image, "leaf.jpg"); f.append("lang", j.lang); f.append("query", j.query); f.append("edge_hint", j.edgeHint);
  const r = await fetch(`${API}/diagnose`, { method: "POST", body: f });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}
export async function transcribe(blob: Blob, lang: string): Promise<string> {
  const f = new FormData(); f.append("audio", blob, "a.webm"); f.append("lang", lang);
  const r = await fetch(`${API}/transcribe`, { method: "POST", body: f });
  return r.ok ? (await r.json()).text : "";
}
export const queued = async (): Promise<Job[]> => (await get("queue")) ?? [];
export const enqueue = async (j: Job) => set("queue", [...(await queued()), j]);
export async function flushQueue(onDone: (j: Job) => void) {
  const rest: Job[] = [];
  for (const j of await queued()) {
    try { j.result = await cloudDiagnose(j); onDone(j); } catch { rest.push(j); }
  }
  await set("queue", rest);
}
