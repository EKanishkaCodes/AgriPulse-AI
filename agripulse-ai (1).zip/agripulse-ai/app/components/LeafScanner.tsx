"use client";
import { useEffect, useRef } from "react";

export default function LeafScanner({ onCapture }: { onCapture: (blob: Blob, canvas: HTMLCanvasElement) => void }) {
  const video = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    let stream: MediaStream | undefined;
    navigator.mediaDevices?.getUserMedia({ video: { facingMode: "environment" } })
      .then(s => { stream = s; if (video.current) video.current.srcObject = s; }).catch(() => {});
    return () => stream?.getTracks().forEach(t => t.stop());
  }, []);
  const snap = () => {
    const v = video.current!; if (!v.videoWidth) return;
    const c = document.createElement("canvas");
    c.width = Math.min(v.videoWidth, 1024); c.height = Math.round(c.width * (v.videoHeight / v.videoWidth));
    c.getContext("2d")!.drawImage(v, 0, 0, c.width, c.height);
    c.toBlob(b => b && onCapture(b, c), "image/jpeg", 0.8);
  };
  return (
    <div className="relative">
      <video ref={video} autoPlay playsInline muted className="w-full rounded-3xl bg-black aspect-[3/4] object-cover" />
      <button onClick={snap} aria-label="Scan leaf"
        className="absolute bottom-4 left-1/2 -translate-x-1/2 w-20 h-20 rounded-full bg-green-700 border-4 border-white text-4xl">📷</button>
      <label className="absolute bottom-6 right-4 w-14 h-14 rounded-full bg-white/90 grid place-items-center text-2xl cursor-pointer">🖼️
        <input type="file" accept="image/*" hidden onChange={e => {
          const f = e.target.files?.[0]; if (!f) return;
          const img = new Image(); img.onload = () => {
            const c = document.createElement("canvas"); c.width = 448; c.height = 448;
            c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height); onCapture(f, c);
          }; img.src = URL.createObjectURL(f);
        }} />
      </label>
    </div>
  );
}
