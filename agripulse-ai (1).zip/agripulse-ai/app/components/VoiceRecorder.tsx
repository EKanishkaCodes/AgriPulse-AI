"use client";
import { useRef, useState } from "react";
import { speechCode } from "../lib/i18n";
import { transcribe } from "../lib/sync";

// One touch: on-device Web Speech API when available, else record audio and send to Whisper on the server.
export default function VoiceRecorder({ lang, onText }: { lang: string; onText: (t: string) => void }) {
  const [on, setOn] = useState(false);
  const rec = useRef<MediaRecorder | null>(null);

  const start = async () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    setOn(true);
    if (SR) {
      const r = new SR(); r.lang = speechCode(lang);
      r.onresult = (e: any) => onText(e.results[0][0].transcript);
      r.onend = () => setOn(false); r.onerror = () => setOn(false); r.start(); return;
    }
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      const chunks: Blob[] = []; const m = new MediaRecorder(s); rec.current = m;
      m.ondataavailable = e => chunks.push(e.data);
      m.onstop = async () => { s.getTracks().forEach(t => t.stop()); setOn(false);
        onText(await transcribe(new Blob(chunks, { type: "audio/webm" }), lang)); };
      m.start(); setTimeout(() => m.state === "recording" && m.stop(), 8000);
    } catch { setOn(false); }
  };
  return (
    <button onClick={on ? () => rec.current?.stop() : start} aria-label="Ask by voice"
      className={`w-full py-5 rounded-2xl text-3xl font-bold ${on ? "bg-red-600 text-white animate-pulse" : "bg-yellow-400 text-black"}`}>
      {on ? "⏹ 🎙️" : "🎙️"}
    </button>
  );
}
