"use client";
import { useEffect } from "react";
import type { Diagnosis } from "../lib/sync";
import { speechCode } from "../lib/i18n";

const COLOR: Record<string, string> = { Low: "bg-green-600", Moderate: "bg-yellow-500", High: "bg-red-600" };
const ICON: Record<string, string> = { Healthy: "✅", Diseased: "🍂", "Pest Infestation": "🐛" };

export function speak(d: Diagnosis, lang: string) {
  if (d.audio_b64) { new Audio(`data:audio/wav;base64,${d.audio_b64}`).play(); return; }
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(d.treatment_plan_vernacular); u.lang = speechCode(lang); u.rate = 0.9;
  speechSynthesis.speak(u);
}

export default function DiagnosticView({ d, lang, pending }: { d?: Diagnosis; lang: string; pending?: string }) {
  useEffect(() => { if (d) speak(d, lang); }, [d, lang]);
  if (!d) return <div className="p-5 rounded-2xl bg-slate-100 text-xl">⏳ {pending ?? "…"}</div>;
  const pct = Math.round(d.confidence_score * 100);
  return (
    <div className="space-y-3">
      <div className="p-5 rounded-2xl bg-slate-100">
        <div className="text-5xl">{ICON[d.health_status] ?? "🌱"}</div>
        <h2 className="text-2xl font-extrabold mt-1">{d.diagnosis_name}</h2>
        <p className="text-lg">🌾 {d.crop_identified}</p>
        <div className="mt-2 flex gap-2 items-center">
          <span className={`px-3 py-1 rounded-full text-white font-bold ${COLOR[d.severity_level] ?? "bg-slate-500"}`}>{d.severity_level}</span>
          <div className="flex-1 h-3 bg-slate-300 rounded"><div className="h-3 bg-green-700 rounded" style={{ width: `${pct}%` }} /></div>
          <span className="font-bold">{pct}%</span>
        </div>
      </div>
      <button onClick={() => speak(d, lang)} className="w-full py-5 rounded-2xl bg-green-700 text-white text-3xl font-bold" aria-label="Play advice">🔊</button>
      <div className="p-5 rounded-2xl bg-green-50 text-xl leading-relaxed">{d.treatment_plan_vernacular}</div>
      <ul className="p-5 rounded-2xl bg-amber-50 text-lg list-disc list-inside">
        {d.preventative_measures.map((m, i) => <li key={i}>{m}</li>)}
      </ul>
    </div>
  );
}
