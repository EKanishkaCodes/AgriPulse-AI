"use client";
import { useEffect, useState } from "react";
import LeafScanner from "./components/LeafScanner";
import VoiceRecorder from "./components/VoiceRecorder";
import DiagnosticView from "./components/DiagnosticView";
import { LANGS } from "./lib/i18n";
import { edgeClassify } from "./lib/edge";
import { cloudDiagnose, enqueue, flushQueue, Diagnosis, Job } from "./lib/sync";

export default function Home() {
  const [lang, setLang] = useState("ta");
  const [query, setQuery] = useState("");
  const [online, setOnline] = useState(true);
  const [edge, setEdge] = useState("");
  const [result, setResult] = useState<Diagnosis>();
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js");
    const up = () => { setOnline(true); flushQueue(j => j.result && setResult(j.result)); };
    const down = () => setOnline(false);
    setOnline(navigator.onLine);
    window.addEventListener("online", up); window.addEventListener("offline", down);
    return () => { window.removeEventListener("online", up); window.removeEventListener("offline", down); };
  }, []);

  const onCapture = async (blob: Blob, canvas: HTMLCanvasElement) => {
    setBusy(true); setResult(undefined); setMsg("");
    const e = await edgeClassify(canvas);                    // 1) instant on-device guess
    const hint = e ? `${e.label} (${Math.round(e.confidence * 100)}%)` : "";
    setEdge(hint);
    const job: Job = { id: crypto.randomUUID(), image: blob, lang, query, edgeHint: hint };
    try {
      if (!navigator.onLine) throw new Error("offline");
      setResult(await cloudDiagnose(job));                   // 2) cloud multimodal enrichment
    } catch {
      await enqueue(job);                                    // 3) queue until connectivity returns
      setMsg("📡 Saved. Will analyze when online.");
    }
    setBusy(false);
  };

  return (
    <main className="max-w-md mx-auto p-4 space-y-4">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-extrabold text-green-900">🌱 AgriPulse</h1>
        <span className={`text-sm px-2 py-1 rounded-full ${online ? "bg-green-100" : "bg-slate-300"}`}>{online ? "🟢 Online" : "⚫ Offline"}</span>
      </header>
      <div className="grid grid-cols-2 gap-2">
        {LANGS.map(l => (
          <button key={l.code} onClick={() => setLang(l.code)}
            className={`py-3 rounded-xl text-lg font-bold border-2 ${lang === l.code ? "bg-green-800 text-white border-green-800" : "border-slate-300"}`}>{l.label}</button>
        ))}
      </div>
      {!result && <LeafScanner onCapture={onCapture} />}
      {!result && <VoiceRecorder lang={lang} onText={setQuery} />}
      {query && !result && <p className="text-lg italic">“{query}”</p>}
      {edge && <p className="text-sm text-slate-600">📱 On-device: {edge}</p>}
      {(busy || result || msg) && <DiagnosticView d={result} lang={lang} pending={msg || "Analyzing…"} />}
      {result && <button onClick={() => { setResult(undefined); setQuery(""); setEdge(""); }} className="w-full py-4 rounded-2xl bg-slate-200 text-3xl" aria-label="Scan again">🔄</button>}
    </main>
  );
}
