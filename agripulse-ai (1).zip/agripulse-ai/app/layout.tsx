import "./globals.css";
import type { Metadata, Viewport } from "next";
export const metadata: Metadata = { title: "AgriPulse AI", manifest: "/manifest.json" };
export const viewport: Viewport = { themeColor: "#14532d", width: "device-width", initialScale: 1 };
export default function Root({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
