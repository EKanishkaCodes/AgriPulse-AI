// Offline asset caching: app shell + model files. API calls are never cached (the app queues them instead).
const CACHE = "agripulse-v1";
const SHELL = ["/", "/manifest.json", "/icon.svg", "/models/labels.json"];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL))); self.skipWaiting(); });
self.addEventListener("activate", e => e.waitUntil(
  caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => clients.claim())));
self.addEventListener("fetch", e => {
  const { request } = e; const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== location.origin) return;
  e.respondWith(caches.match(request).then(hit => hit || fetch(request).then(res => {
    if (res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(request, copy)); }
    return res;
  }).catch(() => caches.match("/"))));
});
