Place your quantized classifier here as `plant_disease.tflite` (e.g. MobileNetV3-small fine-tuned on
PlantVillage / PlantDoc / Cassava, int8-quantized, 224x224 input). Output order must match labels.json.
Without the file the app still works: it skips the edge step and queues photos for cloud diagnosis.
