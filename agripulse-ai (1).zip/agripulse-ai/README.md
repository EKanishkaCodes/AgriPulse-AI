# 🌱 AgriPulse AI
Offline-first, voice-first AI agronomist for smallholder farmers (Agriculture & Rural Development).

**Flow:** photo → on-device TFLite guess (instant, offline) → Gemini vision diagnosis + treatment (when online) →
vernacular voice reply. Photos taken offline are queued in IndexedDB and auto-synced when connectivity returns.

## Run locally
```bash
# 1. Backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # add GEMINI_API_KEY (and GEMINI_MODEL if you want another model)
cd api && uvicorn main:app --reload --port 8000

# 2. Frontend (new terminal, repo root)
cp .env.local.example .env.local
npm install && npm run dev      # http://localhost:3000
```
Camera/mic need HTTPS or localhost. To test on a phone, tunnel both the app and API (e.g. ngrok) and set NEXT_PUBLIC_API_URL.

## Optional pieces
- **Edge model:** drop `plant_disease.tflite` into `public/models/` (see its README). Without it the edge step is skipped.
- **Whisper:** set `OPENAI_API_KEY` for `/transcribe` (fallback when the browser lacks on-device speech recognition).
- **SeamlessM4T TTS:** `ENABLE_SEAMLESS=1` + install transformers/torch/scipy (needs a GPU-class server).
  Otherwise the browser's `speechSynthesis` speaks the reply; voice quality varies for low-resource languages.

## Keypad phones (no smartphone)
`api/phone.py` adds a call menu and SMS via Twilio webhooks: set the number's Voice webhook to `POST /phone/voice` and
Messaging webhook to `POST /phone/sms` (the API must be publicly reachable). Farmers press 1 (English) or 2 (Tamil), then the disease number and #;
the numbered list is in `api/diseases.py` (1-11 now; append to add more). Texting a number returns that disease's advice,
and any other text is answered by Gemini. Check that your telephony provider has a voice for each
language before launch. Calls work from symptoms, not photos.

## Safety notes
- Diagnoses are advisory. Low-confidence results should send the farmer to a local extension worker.
- Have an agronomist review the remedy/dosage guidance for your region before field use.
- Open the app once online so the service worker can cache it for offline use.

## Layout
`app/` Next.js PWA · `api/` FastAPI (Gemini, Whisper, Seamless) · `public/sw.js` offline cache · `public/models/` edge model
